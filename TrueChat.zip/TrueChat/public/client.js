const socket = io()
let name;
let textArea = document.querySelector('#textarea')
let massageArea = document.querySelector('.msg_area')

do{
    name = prompt('please enter your name')
} while(!name){

}

textArea.addEventListener('keyup',(e) => {
    if(e.key === 'Enter'){
        sendMassege(e.target.value)
    }
})

function sendMassege(message){
    let msg = {
        user: name,
        message: message.trim()
    }

    // APPEND

    appendMassege(msg , 'outgoing')
    textArea.value = ''
    scrollToBottom()
    
    // SEND TO SERVER

    socket.emit('message',msg)
}

function appendMassege(msg,type){

    let mainDiv = document.createElement('div')
    let ClassName = type
    mainDiv.classList.add(ClassName , 'msg')

    let markup = `

    <h4>${msg.user}</h4>
    <p>${msg.message}</p>

    `
    mainDiv.innerHTML = markup
    massageArea.appendChild(mainDiv)

}

// RECEIVE MESSEAGE


socket.on('message',(msg) => {
    appendMassege(msg,'incoming')
    scrollToBottom()
})

function scrollToBottom(){
    massageArea.scrollTop = massageArea.scrollHeight
}